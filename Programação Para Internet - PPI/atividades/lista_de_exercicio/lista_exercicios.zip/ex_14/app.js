let numero = prompt("Digite um número:")

while(numero >= 0){
    console.log(numero)
    numero = numero - 1
}