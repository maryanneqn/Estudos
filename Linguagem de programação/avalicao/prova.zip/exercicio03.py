def soma(a , b):
    s = a + b
    print (s)

soma( 10 , 2)

