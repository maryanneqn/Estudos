n1= float(input("Digite o primeiro número: "))
n2= float(input("Digite o segundo número: "))

if n1>n2:
    print(n1, "é maior que", n2)    
else:
    print(n1, "é menor que", n2)
if n1==n2:
    print(n1, "é igual a", n2)