def saudacao(nome ="Visitante"):
    print("Olá,", nome ,"seja bem-vindo ao curso de Python!")
   
  
saudacao()


