def saudacao():
    print("Bem-vindo")

saudacao()



def soma(a, b):
    return a + b

resultado = soma(5, 3)
print(resultado)