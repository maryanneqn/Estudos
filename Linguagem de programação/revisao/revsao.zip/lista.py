frutas = ["maça", "banana", "mamão"]

print(frutas[0])  # Acessa o primeiro elemento da lista
frutas.append("uva")  # Adiciona um novo elemento à lista   
frutas.remove("banana")  # Remove um elemento da lista
frutas[1] = "abacaxi"  # Modifica o segundo elemento da lista
print(frutas)  # Imprime a lista atualizada
