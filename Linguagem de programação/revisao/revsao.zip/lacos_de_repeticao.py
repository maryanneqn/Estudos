for i in range(5):
    print("Olá", i) 


frutas = ["maçã", "banana", "uva"]
for fruta in frutas:
    print(fruta)


contador = 1 

while contador <= 5:
    print("Contador:", contador)
    contador += 1