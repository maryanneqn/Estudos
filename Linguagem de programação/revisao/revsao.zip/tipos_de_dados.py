idade = 18                       #int
altura = 1.75                    #float   
nome = "Mary"                    #str
maior = True                     #bool

