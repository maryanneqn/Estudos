nome = "Mary"
nota_1 = 8.5
nota_2 = 9.0

media = (nota_1 + nota_2) / 2
print(media)