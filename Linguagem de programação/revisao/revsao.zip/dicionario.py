aluno = {
    "nome": "Mary",
    "idade": 18,    
    "nota": 9.0
}

print(aluno["nome"])  # Acessa o valor associado à chave "nome"

aluno["nota"] = 9.5  # Modifica o valor associado à chave "nota"

print(aluno)  # Imprime o dicionário atualizado