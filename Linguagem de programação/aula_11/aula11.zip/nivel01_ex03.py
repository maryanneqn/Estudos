import pyautogui
import time


time.sleep(3) 
pyautogui.moveTo(1794, 5, duration=2)

pyautogui.click(x= 1794, y= 5)