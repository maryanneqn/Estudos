import pyautogui
import time


for i in range(5):
   print(pyautogui.position())
   time.sleep(1)