import pyautogui
import time



time.sleep(1) 
pyautogui.moveTo(1759, 149, duration=2)

time.sleep(1) 
pyautogui.moveTo(497, 430, duration=2)

time.sleep(1) 
pyautogui.moveTo(1224, 688, duration=2)